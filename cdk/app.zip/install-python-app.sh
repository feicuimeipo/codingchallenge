#!/bin/bash


echo 'install python ...'
cd /opt
aws s3 sync s3://arn:aws:s3:ap-east-1:703449490149:accesspoint/mycodingchallenge/app/Python-3.11.3.tgz /opt/
tar -xvf Python-3.11.3.tgz /opt
yum -y install zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gcc make
./configure --prefix=/usr/local/python3
make && make install
ln -s /usr/local/python3 /usr/local/bin/python3.11

echo 'config python ...'
echo 'PATH=/usr/local/python3/bin:$PATH;export PATH;' >> /etc/profile
source /etc/profile
python3


pip3 install pipenv
pip3  install gunicorn
pip3  install flask

pipenv --version
flask  --version
gunicorn -h


mkdir /opt/app
cd /opt/app
rm -rf *
aws s3 sync s3://arn:aws:s3:ap-east-1:703449490149:accesspoint/mycodingchallenge/app/app.tar.gz /opt/app/
tar zxvf app.tar.gz ./
pipenv --python 3
pipenv shell
pipenv install
pipenv install flask
