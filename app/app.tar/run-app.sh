#!/bin/bash
#pipenv install requests -i https://pypi.tuna.tsinghua.edu.cn/simple

cd /opt/app
pipenv shell
flask run 

